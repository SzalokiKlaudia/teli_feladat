# teli_feladat
